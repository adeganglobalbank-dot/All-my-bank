// Global Commodity Market for Indigenous Nigeria
// Owner: Olawale Abdul-Ganiyu

// ==================== GLOBAL VARIABLES ====================
let isLoggedIn = false;
let currentUser = {
    email: '',
    name: '',
    balance: 0,
    profits: 0,
    investments: 0
};

let wallet = {
    balance: 0,
    profits: 0,
    investments: 0,
    transactions: []
};

let portfolio = [];
let plantings = [];
let marketData = {};

// ==================== COMMODITY DATA ====================
const commodities = {
    rice: [
        { name: "Mama's Pride", priceRange: [40000, 55000], currentPrice: 55000, unitsPerBag: 400 },
        { name: "Mama's Choice", priceRange: [42500, 60500], currentPrice: 60500, unitsPerBag: 400 },
        { name: "Mama's Pride (Premium Parboiled)", priceRange: [45000, 55500], currentPrice: 55500, unitsPerBag: 400 },
        { name: "Gerawa Rice", priceRange: [40000, 52500], currentPrice: 52500, unitsPerBag: 400 },
        { name: "Mango Rice", priceRange: [41500, 55500], currentPrice: 55500, unitsPerBag: 400 },
        { name: "Big Bull Stone Rice", priceRange: [48000, 60000], currentPrice: 60000, unitsPerBag: 400 },
        { name: "Siamese", priceRange: [40500, 53200], currentPrice: 53200, unitsPerBag: 400 },
        { name: "Caprice", priceRange: [40000, 57000], currentPrice: 57000, unitsPerBag: 400 },
        { name: "Labana Rice", priceRange: [41000, 50000], currentPrice: 50000, unitsPerBag: 400 },
        { name: "Destoned Ofada Rice", priceRange: [35000, 50000], currentPrice: 50000, unitsPerBag: 400 },
        { name: "Ebonyi Special Rice", priceRange: [40000, 55500], currentPrice: 55500, unitsPerBag: 400 },
        { name: "Mafa Rice", priceRange: [41500, 55000], currentPrice: 55000, unitsPerBag: 400 },
        { name: "Vitali", priceRange: [42500, 58000], currentPrice: 58000, unitsPerBag: 400 },
        { name: "Optimum Parboiled Rice", priceRange: [40000, 55000], currentPrice: 55000, unitsPerBag: 400 },
        { name: "HAB Premium Parboiled Rice", priceRange: [49000, 65000], currentPrice: 65000, unitsPerBag: 400 },
        { name: "Royal Stallion Rice", priceRange: [50000, 65000], currentPrice: 65000, unitsPerBag: 400 },
        { name: "Mama Gold Rice", priceRange: [50000, 67000], currentPrice: 67000, unitsPerBag: 400 }
    ],
    beans: [
        { name: "White Beans", weight: 25, price: 18750, unitsPerBag: 100 },
        { name: "White Beans", weight: 50, price: 37500, unitsPerBag: 200 },
        { name: "White Beans", weight: 100, price: 75000, unitsPerBag: 400 },
        { name: "Brown Beans", weight: 25, price: 19500, unitsPerBag: 100 },
        { name: "Brown Beans", weight: 50, price: 39000, unitsPerBag: 200 },
        { name: "Brown Beans", weight: 100, price: 78000, unitsPerBag: 400 },
        { name: "Honey Beans", weight: 25, price: 20000, unitsPerBag: 100 },
        { name: "Honey Beans", weight: 50, price: 40000, unitsPerBag: 200 },
        { name: "Honey Beans", weight: 100, price: 80000, unitsPerBag: 400 },
        { name: "Oloyin Beans", weight: 25, price: 19000, unitsPerBag: 100 },
        { name: "Oloyin Beans", weight: 50, price: 39000, unitsPerBag: 200 },
        { name: "Olotun Beans", weight: 25, price: 17500, unitsPerBag: 100 },
        { name: "Olotun Beans", weight: 50, price: 36000, unitsPerBag: 200 },
        { name: "Butter Beans", weight: 25, price: 16500, unitsPerBag: 100 },
        { name: "Butter Beans", weight: 50, price: 33000, unitsPerBag: 200 }
    ],
    garri: [
        { name: "Ijebu Garri", priceRange: [35000, 50000], currentPrice: 50000, unitsPerBag: 200, description: "Dry, stone-free, high-quality" },
        { name: "Oyo Garri", priceRange: [30000, 30000], currentPrice: 30000, unitsPerBag: 200, description: "Commonly sold in local markets" },
        { name: "Yellow Garri", priceRange: [45000, 45000], currentPrice: 45000, unitsPerBag: 200, description: "Processed with palm oil" },
        { name: "White Garri", priceRange: [43000, 43000], currentPrice: 43000, unitsPerBag: 200, description: "White variety" }
    ]
};

// ==================== MARKET SIMULATION ====================
let marketTrends = {
    priceMovement: 0,
    demandLevel: 50,
    traderCount: 0,
    lastUpdate: Date.now()
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    initializeCommodities();
    loadFromStorage();
    updateUI();
    startMarketSimulation();
    
    // Login form handler
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        handleLogin();
    });
    
    // Calculator inputs
    document.getElementById('withdrawAmount').addEventListener('input', calculateWithdrawalFee);
});

function initializeCommodities() {
    // Update market data
    updateMarketData();
    
    // Populate calculator commodity dropdown
    const calcSelect = document.getElementById('calcCommodity');
    calcSelect.innerHTML = '<option value="">Select Commodity</option>';
    
    Object.keys(commodities).forEach(type => {
        const optgroup = document.createElement('optgroup');
        optgroup.label = type.charAt(0).toUpperCase() + type.slice(1);
        
        commodities[type].forEach((commodity, index) => {
            const option = document.createElement('option');
            option.value = `${type}-${index}`;
            option.textContent = commodity.name;
            optgroup.appendChild(option);
        });
        
        calcSelect.appendChild(optgroup);
    });
}

function updateMarketData() {
    // Update current prices based on market conditions
    Object.keys(commodities).forEach(type => {
        commodities[type].forEach(commodity => {
            if (commodity.priceRange) {
                // Calculate price based on demand and market conditions
                const priceRange = commodity.priceRange[1] - commodity.priceRange[0];
                const marketFactor = (marketTrends.demandLevel / 100);
                const newPrice = commodity.priceRange[0] + (priceRange * marketFactor);
                commodity.currentPrice = Math.round(newPrice);
            }
        });
    });
    
    // Calculate interest rates (inverse to price)
    calculateInterestRates();
}

function calculateInterestRates() {
    Object.keys(commodities).forEach(type => {
        commodities[type].forEach(commodity => {
            // Higher price = lower interest, Lower price = higher interest
            const baseInterest = 31.25;
            const priceFactor = commodity.currentPrice / 70000; // Normalize
            commodity.interestRate = Math.max(5, Math.min(50, baseInterest / priceFactor));
        });
    });
}

function startMarketSimulation() {
    // Update market every 30 seconds
    setInterval(() => {
        // Random demand fluctuation
        const demandChange = (Math.random() - 0.5) * 10;
        marketTrends.demandLevel = Math.max(10, Math.min(90, marketTrends.demandLevel + demandChange));
        
        // Random trader count change
        const traderChange = Math.floor((Math.random() - 0.5) * 5);
        marketTrends.traderCount = Math.max(0, marketTrends.traderCount + traderChange);
        
        // Price movement
        marketTrends.priceMovement = (Math.random() - 0.5) * 5;
        
        updateMarketData();
        updateUI();
        
        marketTrends.lastUpdate = Date.now();
    }, 30000);
}

// ==================== AUTHENTICATION ====================
function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simple validation
    if (email && password) {
        isLoggedIn = true;
        currentUser.email = email;
        currentUser.name = email.split('@')[0];
        
        // Load user data from storage or create new
        loadUserData(email);
        
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('dashboardSection').style.display = 'block';
        
        updateUI();
        showNotification('Welcome to Global Commodity Market!', 'success');
    }
}

function logout() {
    isLoggedIn = false;
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('loginSection').style.display = 'block';
    
    saveToStorage();
}

// ==================== UI UPDATES ====================
function updateUI() {
    // Update wallet displays
    document.getElementById('walletBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('mainWalletBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('totalInvestments').textContent = formatCurrency(wallet.investments);
    document.getElementById('currentInvestments').textContent = formatCurrency(wallet.investments);
    document.getElementById('totalProfits').textContent = formatCurrency(wallet.profits);
    document.getElementById('totalReturns').textContent = formatCurrency(wallet.profits);
    
    // Update market displays
    document.getElementById('marketGrowth').textContent = marketTrends.priceMovement.toFixed(2);
    document.getElementById('activeTraders').textContent = marketTrends.traderCount;
    
    // Update market trends
    document.getElementById('marketTrend').textContent = getMarketTrend();
    document.getElementById('priceMovement').textContent = getPriceMovementText();
    document.getElementById('demandLevel').textContent = getDemandLevelText();
    
    // Update portfolio
    updatePortfolioDisplay();
    
    // Update plantings
    updatePlantingsDisplay();
    
    // Update wallet activity
    updateWalletActivity();
    
    // Render commodities
    renderCommodities();
}

function formatCurrency(amount) {
    return parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getMarketTrend() {
    if (marketTrends.priceMovement > 1) return 'Bullish 📈';
    if (marketTrends.priceMovement < -1) return 'Bearish 📉';
    return 'Stable ➡️';
}

function getPriceMovementText() {
    if (marketTrends.priceMovement > 1) return 'Rising';
    if (marketTrends.priceMovement < -1) return 'Falling';
    return 'Neutral';
}

function getDemandLevelText() {
    if (marketTrends.demandLevel > 70) return 'High';
    if (marketTrends.demandLevel > 40) return 'Normal';
    return 'Low';
}

// ==================== NAVIGATION ====================
function showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    // Show selected section
    document.getElementById(sectionId + 'Section').style.display = 'block';
    
    // Update nav buttons
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

// ==================== COMMODITY DISPLAY ====================
function renderCommodities() {
    const grid = document.getElementById('commoditiesGrid');
    const filterType = document.getElementById('commodityType').value;
    const sortOption = document.getElementById('sortOption').value;
    
    let allCommodities = [];
    
    // Collect all commodities
    if (filterType === 'all' || filterType === 'rice') {
        commodities.rice.forEach((c, i) => allCommodities.push({...c, type: 'rice', index: i}));
    }
    if (filterType === 'all' || filterType === 'beans') {
        commodities.beans.forEach((c, i) => allCommodities.push({...c, type: 'beans', index: i}));
    }
    if (filterType === 'all' || filterType === 'garri') {
        commodities.garri.forEach((c, i) => allCommodities.push({...c, type: 'garri', index: i}));
    }
    
    // Sort commodities
    allCommodities.sort((a, b) => {
        switch(sortOption) {
            case 'price-asc':
                return a.currentPrice - b.currentPrice;
            case 'price-desc':
                return b.currentPrice - a.currentPrice;
            case 'interest-desc':
                return b.interestRate - a.interestRate;
            case 'name-asc':
                return a.name.localeCompare(b.name);
            default:
                return 0;
        }
    });
    
    // Render
    grid.innerHTML = allCommodities.map(commodity => `
        <div class="commodity-card ${commodity.type}">
            <div class="commodity-header">
                <div>
                    <div class="commodity-name">${commodity.name}</div>
                    <span class="commodity-type">${commodity.type.toUpperCase()}</span>
                </div>
                <div class="trend-indicator ${getTrendClass()}">
                    ${getTrendIcon()}
                </div>
            </div>
            <div class="commodity-price">₦${formatCurrency(commodity.currentPrice)}</div>
            ${commodity.priceRange ? 
                `<div class="price-range">Range: ₦${formatCurrency(commodity.priceRange[0])} - ₦${formatCurrency(commodity.priceRange[1])}</div>` :
                `<div class="price-range">${commodity.weight}kg bag</div>`
            }
            <div class="commodity-stats">
                <div class="stat-item">
                    <div class="stat-label">Interest Rate</div>
                    <div class="stat-value">${commodity.interestRate.toFixed(2)}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Units/Bag</div>
                    <div class="stat-value">${commodity.unitsPerBag}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Price/Unit</div>
                    <div class="stat-value">₦${formatCurrency(commodity.currentPrice / commodity.unitsPerBag)}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Price Trend</div>
                    <div class="stat-value ${getTrendClass()}">${getTrendIcon()}</div>
                </div>
            </div>
            <div class="commodity-actions">
                <button class="btn-success" onclick="buyCommodityDirect('${commodity.type}', ${commodity.index})">Buy Now</button>
                <button class="btn-info" onclick="calculateForCommodity('${commodity.type}', ${commodity.index})">Calculate</button>
            </div>
        </div>
    `).join('');
}

function getTrendClass() {
    return marketTrends.priceMovement > 0 ? 'trend-up' : 'trend-down';
}

function getTrendIcon() {
    return marketTrends.priceMovement > 0 ? '📈' : marketTrends.priceMovement < 0 ? '📉' : '➡️';
}

function filterCommodities() {
    renderCommodities();
}

function sortCommodities() {
    renderCommodities();
}

// ==================== CALCULATOR ====================
function calculateForCommodity(type, index) {
    const select = document.getElementById('calcCommodity');
    select.value = `${type}-${index}`;
    showSection('calculator');
    calculatePrice();
}

function calculatePrice() {
    const commodityValue = document.getElementById('calcCommodity').value;
    const bagSize = parseInt(document.getElementById('calcBagSize').value);
    const quantity = parseInt(document.getElementById('calcQuantity').value);
    
    if (!commodityValue) return;
    
    const [type, index] = commodityValue.split('-');
    const commodity = commodities[type][parseInt(index)];
    
    // Calculate price per unit (using example: 50kg / 400 = 0.125)
    const baseBagSize = 50;
    const baseUnits = commodity.unitsPerBag;
    const pricePerUnit = commodity.currentPrice / baseUnits;
    
    // Calculate for selected bag size
    const bagRatio = bagSize / baseBagSize;
    const costPrice = commodity.currentPrice * bagRatio;
    
    // Calculate interest (retailer profit)
    const interestRate = commodity.interestRate;
    const profit = costPrice * (interestRate / 100);
    const retailPrice = costPrice + profit;
    
    // Calculate total for quantity
    const totalCost = costPrice * quantity;
    const totalRetail = retailPrice * quantity;
    
    // Calculate units in selected bag size
    const unitsInBag = Math.round(baseUnits * bagRatio);
    
    // Update display
    document.getElementById('calcCostPrice').textContent = '₦' + formatCurrency(costPrice);
    document.getElementById('calcInterest').textContent = interestRate.toFixed(2) + '%';
    document.getElementById('calcProfit').textContent = '₦' + formatCurrency(profit);
    document.getElementById('calcTotalCost').textContent = '₦' + formatCurrency(totalCost);
    document.getElementById('calcTotalRetail').textContent = '₦' + formatCurrency(totalRetail);
    document.getElementById('calcUnits').textContent = unitsInBag;
    document.getElementById('calcUnitPrice').textContent = '₦' + formatCurrency(totalRetail / (unitsInBag * quantity));
}

function buyCommodity() {
    const commodityValue = document.getElementById('calcCommodity').value;
    const bagSize = parseInt(document.getElementById('calcBagSize').value);
    const quantity = parseInt(document.getElementById('calcQuantity').value);
    
    if (!commodityValue) {
        showNotification('Please select a commodity', 'error');
        return;
    }
    
    const [type, index] = commodityValue.split('-');
    const commodity = commodities[type][parseInt(index)];
    
    const totalRetail = parseFloat(document.getElementById('calcTotalRetail').textContent.replace('₦', '').replace(/,/g, ''));
    
    if (wallet.balance < totalRetail) {
        showNotification('Insufficient wallet balance', 'error');
        return;
    }
    
    // Deduct from wallet
    wallet.balance -= totalRetail;
    wallet.investments += totalRetail;
    
    // Add to portfolio
    const holding = {
        id: Date.now(),
        type: type,
        name: commodity.name,
        bagSize: bagSize,
        quantity: quantity,
        purchasePrice: totalRetail,
        currentValue: totalRetail,
        purchaseDate: new Date().toISOString()
    };
    
    portfolio.push(holding);
    
    // Add transaction
    addTransaction('debit', totalRetail, `Purchased ${quantity}x ${bagSize}kg ${commodity.name}`);
    
    saveToStorage();
    updateUI();
    
    showNotification(`Successfully purchased ${quantity}x ${bagSize}kg ${commodity.name}!`, 'success');
}

function buyCommodityDirect(type, index) {
    calculateForCommodity(type, index);
}

// ==================== PLANTING INVESTMENT ====================
function calculatePlantingInvestment() {
    const crop = document.getElementById('plantingCrop').value;
    const amount = parseFloat(document.getElementById('plantingAmount').value) || 0;
    const bags = parseInt(document.getElementById('plantingBags').value) || 1;
    
    if (amount < 5000) {
        showNotification('Minimum investment is ₦5,000', 'error');
        return;
    }
    
    // Planting cost is 10%
    const plantingCost = amount * 0.10;
    const investmentAmount = amount - plantingCost;
    
    // Calculate expected yield (3x return)
    const expectedValue = investmentAmount * 3;
    
    // Calculate harvest date (3 months from now)
    const harvestDate = new Date();
    harvestDate.setMonth(harvestDate.getMonth() + 3);
    
    // Update display
    document.getElementById('plantingCost').textContent = '₦' + formatCurrency(plantingCost);
    document.getElementById('expectedYield').textContent = bags + ' bags (estimated)';
    document.getElementById('harvestDate').textContent = harvestDate.toLocaleDateString();
    document.getElementById('estimatedValue').textContent = '₦' + formatCurrency(expectedValue);
}

function startPlanting() {
    const crop = document.getElementById('plantingCrop').value;
    const amount = parseFloat(document.getElementById('plantingAmount').value) || 0;
    const bags = parseInt(document.getElementById('plantingBags').value) || 1;
    
    if (amount < 5000) {
        showNotification('Minimum investment is ₦5,000', 'error');
        return;
    }
    
    if (wallet.balance < amount) {
        showNotification('Insufficient wallet balance', 'error');
        return;
    }
    
    // Deduct from wallet
    wallet.balance -= amount;
    wallet.investments += amount;
    
    const plantingCost = amount * 0.10;
    const investmentAmount = amount - plantingCost;
    
    // Calculate harvest date
    const startDate = new Date();
    const harvestDate = new Date();
    harvestDate.setMonth(harvestDate.getMonth() + 3);
    
    // Create planting investment
    const planting = {
        id: Date.now(),
        crop: crop,
        investmentAmount: investmentAmount,
        plantingCost: plantingCost,
        totalInvested: amount,
        bags: bags,
        startDate: startDate.toISOString(),
        harvestDate: harvestDate.toISOString(),
        status: 'growing',
        expectedValue: investmentAmount * 3
    };
    
    plantings.push(planting);
    
    // Add transaction
    addTransaction('debit', amount, `Started planting investment: ${crop} - ${bags} bags`);
    
    saveToStorage();
    updateUI();
    
    showNotification(`Successfully started planting investment for ${crop}!`, 'success');
}

function updatePlantingsDisplay() {
    const container = document.getElementById('activePlantingsList');
    
    if (plantings.length === 0) {
        container.innerHTML = '<p>No active planting investments</p>';
        return;
    }
    
    container.innerHTML = plantings.map(planting => {
        const startDate = new Date(planting.startDate);
        const harvestDate = new Date(planting.harvestDate);
        const now = new Date();
        const totalDays = Math.ceil((harvestDate - startDate) / (1000 * 60 * 60 * 24));
        const daysPassed = Math.ceil((now - startDate) / (1000 * 60 * 60 * 24));
        const progress = Math.min(100, (daysPassed / totalDays) * 100);
        
        const isHarvested = now >= harvestDate;
        
        return `
            <div class="planting-item">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h4>${planting.crop.charAt(0).toUpperCase() + planting.crop.slice(1)} - ${planting.bags} bags</h4>
                    <span class="badge ${isHarvested ? 'status-active' : 'status-inactive'}">
                        ${isHarvested ? 'Ready for Harvest' : 'Growing'}
                    </span>
                </div>
                <p>Invested: ₦${formatCurrency(planting.totalInvested)}</p>
                <p>Expected Value: ₦${formatCurrency(planting.expectedValue)}</p>
                <p>Harvest Date: ${harvestDate.toLocaleDateString()}</p>
                <div class="planting-progress">
                    <div class="planting-progress-bar" style="width: ${progress}%"></div>
                </div>
                <p>${daysPassed} / ${totalDays} days (${progress.toFixed(1)}%)</p>
                ${isHarvested ? `
                    <button class="btn-success" onclick="harvestPlanting(${planting.id})">Harvest Now</button>
                ` : ''}
            </div>
        `;
    }).join('');
}

function harvestPlanting(plantingId) {
    const plantingIndex = plantings.findIndex(p => p.id === plantingId);
    if (plantingIndex === -1) return;
    
    const planting = plantings[plantingIndex];
    
    // Get current market price for the crop
    const cropPrice = getCurrentCropPrice(planting.crop);
    const harvestValue = planting.expectedValue * (cropPrice / 50000); // Adjust based on market
    
    // Add to wallet
    const profit = harvestValue - planting.totalInvested;
    wallet.balance += harvestValue;
    wallet.profits += profit;
    wallet.investments -= planting.totalInvested;
    
    // Add transaction
    addTransaction('credit', harvestValue, `Harvested ${planting.crop} - Profit: ₦${formatCurrency(profit)}`);
    
    // Remove planting
    plantings.splice(plantingIndex, 1);
    
    saveToStorage();
    updateUI();
    
    showNotification(`Harvested ${planting.crop}! Received ₦${formatCurrency(harvestValue)} (Profit: ₦${formatCurrency(profit)})`, 'success');
}

function getCurrentCropPrice(crop) {
    // Get average price for crop type
    let avgPrice = 50000;
    
    switch(crop) {
        case 'rice':
            avgPrice = commodities.rice.reduce((sum, c) => sum + c.currentPrice, 0) / commodities.rice.length;
            break;
        case 'beans':
            avgPrice = commodities.beans.reduce((sum, c) => sum + c.price, 0) / commodities.beans.length;
            break;
        case 'cassava':
            avgPrice = 40000; // Base price for cassava
            break;
    }
    
    return avgPrice;
}

// ==================== WALLET ====================
function showDepositModal() {
    showNotification('Deposit functionality coming soon', 'info');
}

function showWithdrawModal() {
    showSection('transfers');
    selectTransferType('withdraw');
}

function showTransactionHistory() {
    // Would open a modal with full transaction history
    showNotification('Transaction history coming soon', 'info');
}

function selectTransferType(type) {
    const depositForm = document.getElementById('depositForm');
    const withdrawForm = document.getElementById('withdrawForm');
    const cards = document.querySelectorAll('.transfer-type-card');
    
    cards.forEach(card => card.classList.remove('active'));
    
    if (type === 'deposit') {
        depositForm.style.display = 'block';
        withdrawForm.style.display = 'none';
        cards[0].classList.add('active');
    } else {
        depositForm.style.display = 'none';
        withdrawForm.style.display = 'block';
        cards[1].classList.add('active');
    }
}

function processDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    const method = document.getElementById('depositMethod').value;
    const receipt = document.getElementById('depositReceipt').files[0];
    const reference = document.getElementById('depositReference').value;
    
    if (!amount || amount < 1000) {
        showNotification('Minimum deposit is ₦1,000', 'error');
        return;
    }
    
    if (method === 'bank' && !receipt) {
        showNotification('Please upload payment receipt', 'error');
        return;
    }
    
    // Simulate deposit processing
    showNotification('Deposit submitted for verification. Your wallet will be credited after confirmation.', 'success');
    
    // In production, this would wait for admin approval
    // For demo, we'll credit immediately
    setTimeout(() => {
        wallet.balance += amount;
        addTransaction('credit', amount, `Deposit via ${method}`);
        saveToStorage();
        updateUI();
        showNotification(`₦${formatCurrency(amount)} credited to your wallet!`, 'success');
    }, 2000);
}

function calculateWithdrawalFee() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    const fee = amount * 0.02; // 2% withdrawal fee
    const totalDeductible = amount + fee;
    const amountToReceive = amount;
    
    document.getElementById('withdrawFee').textContent = '₦' + formatCurrency(fee);
    document.getElementById('totalDeductible').textContent = '₦' + formatCurrency(totalDeductible);
    document.getElementById('amountToReceive').textContent = '₦' + formatCurrency(amountToReceive);
}

function processWithdraw() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const bank = document.getElementById('withdrawBank').value;
    const account = document.getElementById('withdrawAccount').value;
    const name = document.getElementById('withdrawName').value;
    const phone = document.getElementById('withdrawPhone').value;
    
    if (!amount || amount < 1000) {
        showNotification('Minimum withdrawal is ₦1,000', 'error');
        return;
    }
    
    if (!bank || !account || !name || !phone) {
        showNotification('Please fill all bank details', 'error');
        return;
    }
    
    const fee = amount * 0.02;
    const totalDeductible = amount + fee;
    
    if (wallet.balance < totalDeductible) {
        showNotification('Insufficient wallet balance', 'error');
        return;
    }
    
    // Process withdrawal
    wallet.balance -= totalDeductible;
    addTransaction('debit', totalDeductible, `Withdrawal to ${bank} - ${account}`);
    
    saveToStorage();
    updateUI();
    
    showNotification(`Withdrawal of ₦${formatCurrency(amount)} processed!`, 'success');
    showNotification(`Confirmation sent to ${phone}`, 'info');
}

// ==================== PORTFOLIO ====================
function updatePortfolioDisplay() {
    // Update portfolio stats
    let totalValue = 0;
    let totalCost = 0;
    
    portfolio.forEach(holding => {
        // Update current value based on market
        const [type, index] = getCommodityIndex(holding.name, holding.type);
        if (type && index !== -1) {
            const commodity = commodities[type][index];
            const currentValue = calculateHoldingValue(holding, commodity);
            holding.currentValue = currentValue;
            totalValue += currentValue;
            totalCost += holding.purchasePrice;
        }
    });
    
    const profitLoss = totalValue - totalCost;
    
    document.getElementById('portfolioValue').textContent = '₦' + formatCurrency(totalValue);
    document.getElementById('holdingsCount').textContent = portfolio.length;
    
    const plElement = document.getElementById('portfolioPL');
    plElement.textContent = '₦' + formatCurrency(profitLoss);
    plElement.className = profitLoss >= 0 ? 'profit' : 'loss';
    
    // Update holdings list
    const holdingsList = document.getElementById('holdingsList');
    if (portfolio.length === 0) {
        holdingsList.innerHTML = '<p>No holdings yet. Start trading commodities!</p>';
    } else {
        holdingsList.innerHTML = portfolio.map(holding => {
            const profit = holding.currentValue - holding.purchasePrice;
            const profitPercent = (profit / holding.purchasePrice) * 100;
            
            return `
                <div class="holding-item">
                    <div class="holding-info">
                        <h4>${holding.name}</h4>
                        <p>${holding.quantity}x ${holding.bagSize}kg</p>
                        <div class="holding-details">
                            <div class="holding-detail">
                                <p>Purchase: ₦${formatCurrency(holding.purchasePrice)}</p>
                                <p>Current: ₦${formatCurrency(holding.currentValue)}</p>
                            </div>
                            <div class="holding-detail">
                                <p>Profit: ₦${formatCurrency(profit)}</p>
                                <p class="${profit >= 0 ? 'profit' : 'loss'}">${profitPercent.toFixed(2)}%</p>
                            </div>
                            <div class="holding-detail">
                                <p>Purchased: ${new Date(holding.purchaseDate).toLocaleDateString()}</p>
                            </div>
                        </div>
                    </div>
                    <div class="holding-actions">
                        <button class="btn-success" onclick="sellHolding(${holding.id})">Sell</button>
                        <button class="btn-info" onclick="viewHoldingDetails(${holding.id})">Details</button>
                    </div>
                </div>
            `;
        }).join('');
    }
}

function getCommodityIndex(name, type) {
    const commoditiesOfType = commodities[type];
    const index = commoditiesOfType.findIndex(c => c.name === name);
    return index !== -1 ? [type, index] : [null, -1];
}

function calculateHoldingValue(holding, commodity) {
    // Calculate current value based on market price
    const basePrice = commodity.currentPrice;
    const bagRatio = holding.bagSize / 50;
    const currentPrice = basePrice * bagRatio;
    return currentPrice * holding.quantity;
}

function sellHolding(holdingId) {
    const holdingIndex = portfolio.findIndex(h => h.id === holdingId);
    if (holdingIndex === -1) return;
    
    const holding = portfolio[holdingIndex];
    const profit = holding.currentValue - holding.purchasePrice;
    
    // Add to wallet
    wallet.balance += holding.currentValue;
    wallet.profits += profit;
    wallet.investments -= holding.purchasePrice;
    
    // Add transaction
    addTransaction('credit', holding.currentValue, `Sold ${holding.quantity}x ${holding.bagSize}kg ${holding.name} - Profit: ₦${formatCurrency(profit)}`);
    
    // Remove from portfolio
    portfolio.splice(holdingIndex, 1);
    
    saveToStorage();
    updateUI();
    
    showNotification(`Sold ${holding.name}! Received ₦${formatCurrency(holding.currentValue)} (Profit: ₦${formatCurrency(profit)})`, 'success');
}

function viewHoldingDetails(holdingId) {
    const holding = portfolio.find(h => h.id === holdingId);
    if (!holding) return;
    
    showNotification(`
        <strong>${holding.name}</strong><br>
        Quantity: ${holding.quantity}x ${holding.bagSize}kg<br>
        Purchase Price: ₦${formatCurrency(holding.purchasePrice)}<br>
        Current Value: ₦${formatCurrency(holding.currentValue)}<br>
        Purchase Date: ${new Date(holding.purchaseDate).toLocaleDateString()}
    `, 'info');
}

// ==================== TRANSACTIONS ====================
function addTransaction(type, amount, description) {
    const transaction = {
        id: Date.now(),
        type: type,
        amount: amount,
        description: description,
        date: new Date().toISOString()
    };
    
    wallet.transactions.unshift(transaction);
}

function updateWalletActivity() {
    const container = document.getElementById('walletActivity');
    const recentTransactions = wallet.transactions.slice(0, 10);
    
    if (recentTransactions.length === 0) {
        container.innerHTML = '<p>No recent activity</p>';
        return;
    }
    
    container.innerHTML = recentTransactions.map(tx => `
        <div class="activity-item">
            <div class="activity-info">
                <div class="activity-type">${tx.description}</div>
                <div class="activity-date">${new Date(tx.date).toLocaleDateString()}</div>
            </div>
            <div class="activity-amount ${tx.type}">
                ${tx.type === 'credit' ? '+' : '-'}₦${formatCurrency(tx.amount)}
            </div>
        </div>
    `).join('');
}

// ==================== STORAGE ====================
function saveToStorage() {
    const data = {
        wallet: wallet,
        portfolio: portfolio,
        plantings: plantings,
        marketTrends: marketTrends,
        currentUser: currentUser
    };
    localStorage.setItem('globalCommodityMarket', JSON.stringify(data));
}

function loadFromStorage() {
    const data = localStorage.getItem('globalCommodityMarket');
    if (data) {
        const parsed = JSON.parse(data);
        wallet = parsed.wallet || wallet;
        portfolio = parsed.portfolio || [];
        plantings = parsed.plantings || [];
        marketTrends = parsed.marketTrends || marketTrends;
        currentUser = parsed.currentUser || currentUser;
    }
}

function loadUserData(email) {
    // Load user-specific data
    const userData = localStorage.getItem('user_' + email);
    if (userData) {
        const parsed = JSON.parse(userData);
        wallet = parsed.wallet || wallet;
        portfolio = parsed.portfolio || [];
        plantings = parsed.plantings || [];
    }
}

// ==================== NOTIFICATIONS ====================
function showNotification(message, type = 'info') {
    const modal = document.getElementById('notificationModal');
    const modalMessage = document.getElementById('modalMessage');
    
    let bgColor = '#4facfe';
    if (type === 'success') bgColor = '#38ef7d';
    if (type === 'error') bgColor = '#f45c43';
    if (type === 'warning') bgColor = '#f093fb';
    
    modalMessage.innerHTML = `
        <div style="background: ${bgColor}; color: white; padding: 20px; border-radius: 10px; text-align: center;">
            <h3 style="margin-bottom: 10px;">${type.charAt(0).toUpperCase() + type.slice(1)}</h3>
            <p>${message}</p>
        </div>
    `;
    
    modal.style.display = 'block';
    
    // Auto close after 5 seconds
    setTimeout(() => {
        closeModal('notificationModal');
    }, 5000);
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('notificationModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}