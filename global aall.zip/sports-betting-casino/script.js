// NinjaBet & Casino - Premium Betting Platform
// Owner: Olawale Abdul-Ganiyu

// ==================== GLOBAL VARIABLES ====================
let currentUser = null;
let betSlip = [];
let wallet = {
    balance: 0,
    deposits: 0,
    withdrawals: 0,
    staked: 0,
    winnings: 0
};

let bettingHistory = [];
let activeBets = [];

// Sample matches data
const matches = [
    {
        id: 1,
        league: 'English Premier League',
        date: '2024-12-15',
        time: '15:00',
        homeTeam: 'Manchester United',
        awayTeam: 'Liverpool',
        odds: {
            home: 2.50,
            draw: 3.40,
            away: 2.80
        },
        status: 'upcoming'
    },
    {
        id: 2,
        league: 'English Premier League',
        date: '2024-12-15',
        time: '17:30',
        homeTeam: 'Chelsea',
        awayTeam: 'Arsenal',
        odds: {
            home: 2.20,
            draw: 3.60,
            away: 3.10
        },
        status: 'upcoming'
    },
    {
        id: 3,
        league: 'La Liga',
        date: '2024-12-15',
        time: '20:00',
        homeTeam: 'Real Madrid',
        awayTeam: 'Barcelona',
        odds: {
            home: 2.40,
            draw: 3.30,
            away: 2.90
        },
        status: 'live'
    },
    {
        id: 4,
        league: 'Serie A',
        date: '2024-12-15',
        time: '18:45',
        homeTeam: 'Juventus',
        awayTeam: 'AC Milan',
        odds: {
            home: 2.10,
            draw: 3.40,
            away: 3.50
        },
        status: 'upcoming'
    },
    {
        id: 5,
        league: 'Bundesliga',
        date: '2024-12-16',
        time: '19:30',
        homeTeam: 'Bayern Munich',
        awayTeam: 'Borussia Dortmund',
        odds: {
            home: 1.80,
            draw: 3.80,
            away: 4.20
        },
        status: 'upcoming'
    },
    {
        id: 6,
        league: 'NPFL',
        date: '2024-12-16',
        time: '16:00',
        homeTeam: 'Enyimba',
        awayTeam: 'Rangers',
        odds: {
            home: 2.60,
            draw: 3.20,
            away: 2.70
        },
        status: 'upcoming'
    }
];

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    
    // Check if user is logged in
    const loggedInUser = localStorage.getItem('bettingUser');
    if (loggedInUser) {
        currentUser = JSON.parse(loggedInUser);
        showDashboard();
    }
    
    // Render matches
    renderMatches();
    renderLiveMatches();
});

// ==================== AUTHENTICATION ====================
function showRegister() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}

function showLogin() {
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
}

function handleRegister() {
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regConfirmPassword').value;
    
    if (!name || !email || !phone || !password) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    // Create user
    currentUser = {
        id: Date.now(),
        name: name,
        email: email,
        phone: phone,
        password: password,
        joinDate: new Date().toISOString()
    };
    
    wallet.balance = 0;
    saveToStorage();
    
    showNotification('Registration successful! Welcome to NinjaBet & Casino', 'success');
    showDashboard();
}

function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    const users = JSON.parse(localStorage.getItem('bettingUsers') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
        showNotification('Invalid email or password', 'error');
        return;
    }
    
    currentUser = user;
    localStorage.setItem('bettingUser', JSON.stringify(currentUser));
    
    showNotification('Welcome back, ' + user.name + '!', 'success');
    showDashboard();
}

function logout() {
    currentUser = null;
    betSlip = [];
    localStorage.removeItem('bettingUser');
    
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('dashboardSection').style.display = 'none';
    
    saveToStorage();
}

// ==================== DASHBOARD ====================
function showDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    
    // Update user info
    if (currentUser) {
        document.getElementById('profileName').textContent = currentUser.name;
        document.getElementById('profileEmail').textContent = currentUser.email;
        document.getElementById('profilePhone').textContent = currentUser.phone;
        document.getElementById('memberSince').textContent = new Date(currentUser.joinDate).toLocaleDateString();
    }
    
    updateWalletDisplay();
    updateBetHistory();
}

// ==================== NAVIGATION ====================
function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    document.getElementById(sectionId + 'Section').style.display = 'block';
    
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

// ==================== MATCHES ====================
function renderMatches() {
    const matchesList = document.getElementById('matchesList');
    
    const upcomingMatches = matches.filter(m => m.status === 'upcoming');
    
    matchesList.innerHTML = upcomingMatches.map(match => `
        <div class="match-card">
            <div class="match-header">
                <span class="match-date">${formatDate(match.date)} at ${match.time}</span>
                <span class="match-league">${match.league}</span>
            </div>
            <div class="match-teams">
                <div class="team">
                    <div class="team-name">${match.homeTeam}</div>
                </div>
                <div class="match-time">VS</div>
                <div class="team">
                    <div class="team-name">${match.awayTeam}</div>
                </div>
            </div>
            <div class="match-odds">
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'home', ${match.odds.home}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">1</div>
                    <div class="odd-value">${match.odds.home.toFixed(2)}</div>
                </div>
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'draw', ${match.odds.draw}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">X</div>
                    <div class="odd-value">${match.odds.draw.toFixed(2)}</div>
                </div>
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'away', ${match.odds.away}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">2</div>
                    <div class="odd-value">${match.odds.away.toFixed(2)}</div>
                </div>
            </div>
        </div>
    `).join('');
}

function renderLiveMatches() {
    const liveMatches = document.getElementById('liveMatches');
    
    const live = matches.filter(m => m.status === 'live');
    
    if (live.length === 0) {
        liveMatches.innerHTML = '<p class="empty-slip">No live matches at the moment</p>';
        return;
    }
    
    liveMatches.innerHTML = live.map(match => `
        <div class="match-card" style="border-color: #f44336;">
            <div class="match-header">
                <span class="match-date" style="color: #f44336;">🔴 LIVE - ${formatDate(match.date)}</span>
                <span class="match-league">${match.league}</span>
            </div>
            <div class="match-teams">
                <div class="team">
                    <div class="team-name">${match.homeTeam}</div>
                </div>
                <div class="match-time" style="color: #f44336;">LIVE</div>
                <div class="team">
                    <div class="team-name">${match.awayTeam}</div>
                </div>
            </div>
            <div class="match-odds">
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'home', ${match.odds.home}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">1</div>
                    <div class="odd-value">${match.odds.home.toFixed(2)}</div>
                </div>
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'draw', ${match.odds.draw}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">X</div>
                    <div class="odd-value">${match.odds.draw.toFixed(2)}</div>
                </div>
                <div class="odd-button" onclick="addToBetSlip(${match.id}, 'away', ${match.odds.away}, '${match.homeTeam} vs ${match.awayTeam}')">
                    <div class="odd-label">2</div>
                    <div class="odd-value">${match.odds.away.toFixed(2)}</div>
                </div>
            </div>
        </div>
    `).join('');
}

function filterSports() {
    const sport = document.getElementById('sportFilter').value;
    // Implementation for filtering by sport
}

function filterLeagues() {
    const league = document.getElementById('leagueFilter').value;
    // Implementation for filtering by league
}

// ==================== BET SLIP ====================
function addToBetSlip(matchId, selection, odds, matchName) {
    // Check if selection already exists
    const existingIndex = betSlip.findIndex(b => b.matchId === matchId);
    
    if (existingIndex !== -1) {
        betSlip.splice(existingIndex, 1);
    }
    
    betSlip.push({
        matchId: matchId,
        selection: selection,
        odds: odds,
        matchName: matchName
    });
    
    updateBetSlip();
    showNotification('Selection added to bet slip', 'success');
}

function removeFromBetSlip(index) {
    betSlip.splice(index, 1);
    updateBetSlip();
}

function clearBetSlip() {
    betSlip = [];
    updateBetSlip();
}

function updateBetSlip() {
    const betSlipDiv = document.getElementById('betSlip');
    const betSlipOptions = document.getElementById('betSlipOptions');
    
    if (betSlip.length === 0) {
        betSlipDiv.innerHTML = '<p class="empty-slip">No selections in bet slip</p>';
        betSlipOptions.style.display = 'none';
        return;
    }
    
    betSlipDiv.innerHTML = betSlip.map((bet, index) => `
        <div class="bet-selection">
            <div>
                <div style="font-weight: 600;">${bet.matchName}</div>
                <div style="color: #f093fb;">Selection: ${bet.selection.toUpperCase()}</div>
                <div style="font-size: 1.2em; font-weight: 700;">Odds: ${bet.odds.toFixed(2)}</div>
            </div>
            <button class="bet-remove" onclick="removeFromBetSlip(${index})">✕</button>
        </div>
    `).join('');
    
    betSlipOptions.style.display = 'block';
    updatePotentialWinning();
}

function updatePotentialWinning() {
    const stake = parseFloat(document.getElementById('stakeAmount').value) || 0;
    const totalOdds = betSlip.reduce((sum, bet) => sum * bet.odds, 1);
    
    document.getElementById('totalOdds').textContent = totalOdds.toFixed(2);
    
    const potentialWinning = stake * totalOdds;
    const exciseTax = potentialWinning * 0.075;
    const netWinning = potentialWinning - exciseTax;
    
    document.getElementById('potentialWinning').textContent = formatCurrency(potentialWinning);
    document.getElementById('exciseTax').textContent = formatCurrency(exciseTax);
    document.getElementById('netWinning').textContent = formatCurrency(netWinning);
}

function placeBet() {
    const stake = parseFloat(document.getElementById('stakeAmount').value) || 0;
    const betType = document.getElementById('betType').value;
    
    if (betSlip.length === 0) {
        showNotification('Add selections to bet slip first', 'error');
        return;
    }
    
    if (stake < 100) {
        showNotification('Minimum stake is ₦100', 'error');
        return;
    }
    
    if (stake > wallet.balance) {
        showNotification('Insufficient balance. Please deposit funds.', 'error');
        return;
    }
    
    const totalOdds = betSlip.reduce((sum, bet) => sum * bet.odds, 1);
    const potentialWinning = stake * totalOdds;
    const exciseTax = potentialWinning * 0.075;
    const netWinning = potentialWinning - exciseTax;
    
    // Deduct stake from wallet
    wallet.balance -= stake;
    wallet.staked += stake;
    
    // Create bet record
    const bet = {
        id: Date.now(),
        userId: currentUser.id,
        selections: [...betSlip],
        stake: stake,
        totalOdds: totalOdds,
        potentialWinning: potentialWinning,
        exciseTax: exciseTax,
        netWinning: netWinning,
        betType: betType,
        status: 'pending',
        createdAt: new Date().toISOString()
    };
    
    activeBets.push(bet);
    bettingHistory.unshift(bet);
    
    // Clear bet slip
    betSlip = [];
    document.getElementById('stakeAmount').value = '';
    updateBetSlip();
    
    saveToStorage();
    updateWalletDisplay();
    updateBetHistory();
    
    showNotification(`Bet placed successfully! Stake: ₦${formatCurrency(stake)}`, 'success');
    showSection('history');
}

// ==================== CASINO GAMES ====================
function openGame(gameType) {
    const gameTitle = document.getElementById('gameTitle');
    const gameArea = document.getElementById('gameArea');
    
    const games = {
        roulette: '🎰 Roulette',
        blackjack: '🃏 Blackjack',
        slots: '🎰 Slot Machines',
        poker: '🎴 Video Poker',
        baccarat: '🎲 Baccarat',
        dice: '🎲 Dice Games'
    };
    
    gameTitle.textContent = games[gameType] || 'Game';
    
    // Game placeholder
    gameArea.innerHTML = `
        <div style="text-align: center; padding: 50px;">
            <div style="font-size: 5em; margin-bottom: 30px;">${games[gameType].split(' ')[0]}</div>
            <h2 style="margin-bottom: 20px; color: #f093fb;">${games[gameType]}</h2>
            <p style="margin-bottom: 30px; color: #888;">Loading game...</p>
            <div class="game-loading-spinner"></div>
            <p style="margin-top: 30px; color: #888;">Minimum bet: ₦100 | Maximum bet: ₦100,000</p>
        </div>
    `;
    
    document.getElementById('gameModal').style.display = 'flex';
}

// ==================== WALLET ====================
function updateWalletDisplay() {
    document.getElementById('walletBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('mainBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('totalDeposits').textContent = formatCurrency(wallet.deposits);
    document.getElementById('totalWithdrawals').textContent = formatCurrency(wallet.withdrawals);
    document.getElementById('totalStaked').textContent = formatCurrency(wallet.staked);
    document.getElementById('totalWinnings').textContent = formatCurrency(wallet.winnings);
    document.getElementById('activeBets').textContent = activeBets.length;
    
    // Calculate net profit/loss
    const netProfitLoss = wallet.winnings - wallet.staked;
    const netProfitLossElement = document.getElementById('netProfitLoss');
    netProfitLossElement.textContent = formatCurrency(netProfitLoss);
    netProfitLossElement.style.color = netProfitLoss >= 0 ? '#4caf50' : '#f44336';
}

function showDepositModal() {
    document.getElementById('depositModal').style.display = 'flex';
}

function showWithdrawModal() {
    document.getElementById('withdrawAvailableBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('withdrawModal').style.display = 'flex';
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

function processDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value) || 0;
    const method = document.getElementById('depositMethod').value;
    
    if (amount < 100) {
        showNotification('Minimum deposit is ₦100', 'error');
        return;
    }
    
    // Add to wallet
    wallet.balance += amount;
    wallet.deposits += amount;
    
    saveToStorage();
    updateWalletDisplay();
    closeModals();
    
    showNotification(`Deposit of ₦${formatCurrency(amount)} successful via ${method.toUpperCase()}`, 'success');
    document.getElementById('depositAmount').value = '';
}

function processWithdrawal() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    const bank = document.getElementById('withdrawBank').value;
    const accountNumber = document.getElementById('withdrawAccountNumber').value;
    const accountName = document.getElementById('withdrawAccountName').value;
    
    if (amount < 500) {
        showNotification('Minimum withdrawal is ₦500', 'error');
        return;
    }
    
    if (accountNumber.length !== 10) {
        showNotification('Account number must be 10 digits', 'error');
        return;
    }
    
    if (amount > wallet.balance) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    if (!accountName) {
        showNotification('Please enter account name', 'error');
        return;
    }
    
    // Deduct from wallet
    wallet.balance -= amount;
    wallet.withdrawals += amount;
    
    saveToStorage();
    updateWalletDisplay();
    closeModals();
    
    showNotification(`Withdrawal of ₦${formatCurrency(amount)} to ${accountName} (${bank}) submitted for processing`, 'success');
    document.getElementById('withdrawAmount').value = '';
    document.getElementById('withdrawAccountNumber').value = '';
    document.getElementById('withdrawAccountName').value = '';
}

// ==================== BETTING HISTORY ====================
function updateBetHistory() {
    const betHistoryDiv = document.getElementById('betHistory');
    
    if (bettingHistory.length === 0) {
        betHistoryDiv.innerHTML = '<p class="empty-slip">No betting history</p>';
        return;
    }
    
    betHistoryDiv.innerHTML = bettingHistory.slice(0, 20).map(bet => `
        <div class="history-item">
            <div class="history-header">
                <div>
                    <span style="font-weight: 600;">Bet #${bet.id}</span>
                    <span style="color: #888;">| ${new Date(bet.createdAt).toLocaleString()}</span>
                </div>
                <span class="status-badge ${bet.status}">${bet.status.toUpperCase()}</span>
            </div>
            <div class="history-details">
                <p><span>Stake:</span> ₦${formatCurrency(bet.stake)}</p>
                <p><span>Total Odds:</span> ${bet.totalOdds.toFixed(2)}</p>
                <p><span>Potential:</span> ₦${formatCurrency(bet.netWinning)}</p>
                <p><span>Bet Type:</span> ${bet.betType}</p>
                <p><span>Selections:</span> ${bet.selections.length}</p>
            </div>
        </div>
    `).join('');
}

function filterHistory() {
    const filter = document.getElementById('historyFilter').value;
    // Implementation for filtering history
}

// ==================== UTILITY FUNCTIONS ====================
function formatCurrency(amount) {
    return parseFloat(amount).toLocaleString('en-NG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ==================== STORAGE ====================
function saveToStorage() {
    localStorage.setItem('bettingWallet', JSON.stringify(wallet));
    localStorage.setItem('bettingHistory', JSON.stringify(bettingHistory));
    localStorage.setItem('bettingActive', JSON.stringify(activeBets));
    
    if (currentUser) {
        const users = JSON.parse(localStorage.getItem('bettingUsers') || '[]');
        const userIndex = users.findIndex(u => u.id === currentUser.id);
        if (userIndex !== -1) {
            users[userIndex] = currentUser;
        } else {
            users.push(currentUser);
        }
        localStorage.setItem('bettingUsers', JSON.stringify(users));
    }
}

function loadFromStorage() {
    const storedWallet = localStorage.getItem('bettingWallet');
    if (storedWallet) {
        wallet = JSON.parse(storedWallet);
    }
    
    const storedHistory = localStorage.getItem('bettingHistory');
    if (storedHistory) {
        bettingHistory = JSON.parse(storedHistory);
    }
    
    const storedActive = localStorage.getItem('bettingActive');
    if (storedActive) {
        activeBets = JSON.parse(storedActive);
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModals();
    }
}